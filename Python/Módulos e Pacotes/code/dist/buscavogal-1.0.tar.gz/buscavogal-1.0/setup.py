from setuptools import setup

setup(
    name="buscavogal",
    version="1.0",
    description="Use a cabeça! Python Ferramenta de Pesquisa",
    author="Bruno Oliveira",
    author_mail="bruoli3@gmail.com",
    url="headfirstlab.com",
    py_modules=["buscavogal"],
)
    
